let numeroUsuario = prompt("Ingrese un número");
for (let i = 1; i <= 10; i++) {
    let resultado = numeroUsuario * i;
    alert(numeroUsuario + " x " + i +" = " + resultado);
}
